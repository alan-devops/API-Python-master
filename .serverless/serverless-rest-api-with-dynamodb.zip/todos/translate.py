import json
import boto3
#dynamodb = boto3.resource('dynamodb')




#import boto3
def translate(event, context):
    data = json.loads(event['body'])
    translate = boto3.client('translate')
    result = translate.translate_text(Text=data['text'],
                                      SourceLanguageCode=data['idiomaO'],
                                      TargetLanguageCode=data['idiomaD'])

    print(f'TranslatedText: {result["TranslatedText"]}')
    print(f'SourceLanguageCode: {result["SourceLanguageCode"]}')
    print(f'TargetLanguageCode: {result["TargetLanguageCode"]}')


    # create a response
    response = {
        "statusCode": 200,
        "body": json.dumps(result["TranslatedText"])
    }

    return response